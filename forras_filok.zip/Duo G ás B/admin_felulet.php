<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Felület</title>
    <link rel="stylesheet" href="admin_felulet.css">
</head>
<body>
    <div class="elso">
        <img src="logoka.png" alt="Logo" class="logo">
    </div>
    <nav class="menu">
        <ul>
            <li><a href="admin_felulet.php">AJÁNLATKÉRÉSEK</a></li>  
            <li><a href="klima_hozzaadas.php">KLÍMA KEZELÉS</a></li>  
            <li><a href="Index.html">KIJELENTKEZÉS</a></li>
        </ul>
    </nav>
    <h2 align="center">Admin Felület</h2>

    <section class="admin-section">
        <h3>Ajánlatkérések megtekintése</h3>
        <table>
            <thead>
                <tr>
                    <th>Rendelés ID</th>
                    <th>Ügyfél Név</th>
                    <th>Email</th>
                    <th>Üzenet</th>
                    <th>Dátum</th>
                    <th>Statusz</th>
                    <th>Megnézve</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    require_once 'config.php';

                    try {
                        $sql = "SELECT * FROM urlap";
                        $stmt = $pdo->query($sql);

                        if ($stmt->rowCount() > 0) {
                            while($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                                $statusIcon = $row['statusz'] == 1 ? '✔️' : '❌';
                                echo "<tr>
                                        <td>" . htmlspecialchars($row['id']) . "</td>
                                        <td>" . htmlspecialchars($row['ugyfel_nev']) . "</td>
                                        <td>" . htmlspecialchars($row['email']) . "</td>
                                        <td>" . nl2br(htmlspecialchars($row['uzenetek'])) . "</td>
                                        <td>" . htmlspecialchars($row['datum']) . "</td>
                                        <td>" . $statusIcon . "</td>
                                        <td>
                                            <form method='POST' action='statusz_frissit.php'>
                                                <input type='hidden' name='rendeles_id' value='" . htmlspecialchars($row['id']) . "'>
                                                <input type='submit' name='update_status' value='Frissítés'>
                                            </form>
                                        </td>
                                    </tr>";
                            }
                        } else {
                            echo "<tr><td colspan='7'>Nincsenek rendelési adatok.</td></tr>";
                        }
                    } catch (PDOException $e) {
                        echo "<tr><td colspan='7'>Hiba: " . $e->getMessage() . "</td></tr>";
                    }
                ?>
            </tbody>
        </table>
    </section>

    <footer class="footer">
        <ul>
            <li><a href="admin_felulet.php">Admin Kezdőlap</a></li>
            <li><a href="rendelesek.php">Rendelések</a></li>
            <li><a href="klima_hozzaadas.php">Klíma Hozzáadása</a></li>
            <li><a href="klima_torles.php">Klíma Törlése</a></li>
            <li><a href="kilepes.php">Kijelentkezés</a></li>
        </ul>
        <p>&copy; 2024 F&H. Minden jog fenntartva.</p>
        <p>A weboldalt készítette: Bigors Barnabás, Dobó Gergő és Tóth Dániel</p>
    </footer>
</body>
</html>
