<?php
require_once 'config.php';
?>
<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Termékek</title>
    <link rel="stylesheet" href="termek.css">
</head>
<body>
<div class="elso">
    <img src="logoka.png" alt="Logo" class="logo">
</div>
<nav class="menu">
    <ul>
        <li><a href="Index.html">KEZDŐLAP</a></li>
        <li><a href="termekek.php">TERMÉKEK</a></li>
        <li><a href="ajanlatkeres.html">AJÁNLATKÉRÉS</a></li>
        <li><a href="kapcsolat.html">KAPCSOLAT</a></li>
    </ul>
</nav>
<table>
    <thead>
        <tr>
            <th>Termék neve</th>
            <th>Márka</th>
            <th>Energiaosztály</th>
            <th>Ár</th>
            <th>WiFi</th>
            <th>Hűtőközeg</th>
        </tr>
    </thead>
    <tbody>
        <?php
        $sql = "SELECT t.termeknev, m.nev AS marka, e.osztaly AS energiaosztaly, 
                       t.ar, t.wifi, h.gaztipus AS hutokozeg
                FROM termekek t
                JOIN marka m ON t.marka_id = m.marka_id
                JOIN energiaosztaly e ON t.energiaosztaly_id = e.energiaosztaly_id
                JOIN hutokozeg h ON t.hutokozeg_id = h.hutokozeg_id";

        try {
            $stmt = $pdo->query($sql);
            $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

            if (count($rows) > 0) {
                foreach ($rows as $row) {
                    echo "<tr>";
                    echo "<td>" . htmlspecialchars($row['termeknev']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['marka']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['energiaosztaly']) . "</td>";
                    echo "<td>" . number_format($row['ar'], 0, ',', ' ') . " Ft</td>";
                    echo "<td>" . ($row['wifi'] ? 'Igen' : 'Nem') . "</td>";
                    echo "<td>" . htmlspecialchars($row['hutokozeg']) . "</td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='6'>Nincs elérhető termék</td></tr>";
            }
        } catch (PDOException $e) {
            echo "<tr><td colspan='6'>Hiba történt az adatok lekérésekor: " . $e->getMessage() . "</td></tr>";
        }
        ?>
    </tbody>
</table>

<footer class="footer">
    <ul>
        <li><a href="Index.html">Kezdőlap</a></li>
        <li><a href="termekek.php">Termékek</a></li>
        <li><a href="ajanlatkeres.html">Ajánlatkérés</a></li>
        <li><a href="kapcsolat.html">Kapcsolat</a></li>
    </ul>
    <p>&copy; 2024 F&H. Minden jog fenntartva.</p>
    <p>A weboldalt készítette: Bigors Barnabás, Dobó Gergő és Tóth Dániel</p>
</footer>

</body>
</html>
