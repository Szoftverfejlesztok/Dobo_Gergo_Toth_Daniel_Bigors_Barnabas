<?php
require_once 'config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $klima_nev = trim($_POST['nev']);
    $tipus = trim($_POST['tipus']);
    $ar = floatval($_POST['ar']);
    $leiras = trim($_POST['leiras']);

    try {
        $stmt = $pdo->prepare("INSERT INTO termekek (termekek_nev, tipus, ar, leiras) VALUES (:klima_nev, :tipus, :ar, :leiras)");
        $stmt->bindParam(':klima_nev', $klima_nev, PDO::PARAM_STR);
        $stmt->bindParam(':tipus', $tipus, PDO::PARAM_STR);
        $stmt->bindParam(':ar', $ar);
        $stmt->bindParam(':leiras', $leiras, PDO::PARAM_STR);

        if ($stmt->execute()) {
            echo "<script>alert('Klíma sikeresen hozzáadva!'); window.location.href = 'klima_hozzaadas.php';</script>";
        } else {
            echo "<script>alert('Hiba történt a mentés során!'); window.history.back();</script>";
        }
    } catch (PDOException $e) {
        echo "<script>alert('Adatbázis hiba: " . $e->getMessage() . "'); window.history.back();</script>";
    }
}
?>

