<?php
require_once 'config.php'; // Ez tartalmazza a $pdo definícióját

try {
    $sql = "SELECT * FROM termekek";
    $stmt = $pdo->query($sql);
    $klimak = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if (count($klimak) > 0) {
        foreach ($klimak as $row) {
            echo "<tr>
                    <td>" . htmlspecialchars($row["id"]) . "</td>
                    <td>" . htmlspecialchars($row["termeknev"]) . "</td>
                    <td>" . number_format($row["ar"], 0, ',', ' ') . " Ft</td>
                    <td>" . htmlspecialchars($row["leiras"]) . "</td>
                    <td>
                        <a href='klima_torles.php?id=" . $row["id"] . "' onclick='return confirm(\"Biztosan törölni szeretné ezt a klímát?\");'>Törlés</a>
                    </td>
                  </tr>";
        }
    } else {
        echo "<tr><td colspan='6'>Nincsenek elérhető klímák.</td></tr>";
    }
} catch (PDOException $e) {
    echo "<tr><td colspan='6'>Hiba történt: " . htmlspecialchars($e->getMessage()) . "</td></tr>";
}
?>
