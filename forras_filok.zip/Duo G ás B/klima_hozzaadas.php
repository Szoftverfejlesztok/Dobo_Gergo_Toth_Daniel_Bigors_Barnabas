<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Klíma Kezelés</title>
    <link rel="stylesheet" href="admin_felulet.css">
</head>
<body>
    <div class="elso">
        <img src="logoka.png" alt="Logo" class="logo">
    </div>
    <nav class="menu">
        <ul>
            <li><a href="admin_felulet.php">AJÁNLATKÉRÉSEK</a></li>
            <li><a href="klima_hozzaadas.php">KLÍMA KEZELÉS</a></li>
            <li><a href="Index.html">KIJELENTKEZÉS</a></li>
        </ul>
    </nav>
    <h2 align="center">Klíma Kezelés</h2>

    <!-- Klíma hozzáadása form -->
    <section class="admin-section">
        <h3>Új Klíma Hozzáadása</h3>
        <form action="klima_hozzaadas_process.php" method="POST">
            <label for="nev">Klíma Név:</label>
            <input type="text" id="nev" name="nev" required>
            
            <label for="tipus">Típus:</label>
            <input type="text" id="tipus" name="tipus" required>
            
            <label for="ar">Ár:</label>
            <input type="number" id="ar" name="ar" required>
            
            <label for="leiras">Leírás:</label>
            <textarea id="leiras" name="leiras" rows="5" required></textarea>
            
            <input type="submit" value="Klíma Hozzáadása">
        </form>
    </section>

    <!-- Klímák listázása és törlés -->
    <section class="admin-section">
        <h3>Megrendelhető Klímák</h3>
        <table>
            <thead>
                <tr>
                    <th>Klíma ID</th>
                    <th>Klíma Név</th>
                    <th>Ár</th>
                    <th>Leírás</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <!-- Itt jelennek meg a klíma adatai a PHP script segítségével -->
                <?php include('klima_lista.php'); ?>
            </tbody>
        </table>
    </section>

    <footer class="footer">
        <ul>
            <li><a href="admin_felulet.html">Admin Kezdőlap</a></li>
            <li><a href="rendelesek.php">Rendelések</a></li>
            <li><a href="klima_hozzaadas.php">Klíma Hozzáadása</a></li>
            <li><a href="klima_torles.php">Klíma Törlése</a></li>
            <li><a href="kilepes.php">Kijelentkezés</a></li>
        </ul>
        <p>&copy; 2024 F&H. Minden jog fenntartva.</p>
        <p>A weboldalt készítette: Bigors Barnabás, Dobó Gergő és Tóth Dániel</p>
    </footer>
</body>
</html>
