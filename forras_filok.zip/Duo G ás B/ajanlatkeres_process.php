<?php
session_start();
require_once 'config.php';

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Űrlapmezők ellenőrzése
    if (empty($_POST['nev']) || empty($_POST['email']) || empty($_POST['uzenet'])) {
        echo "<script>alert('Kérjük, minden mezőt tölts ki!'); window.history.back();</script>";
        exit();
    }

    // Adatok tisztítása
    $ugyfel_nev = trim($_POST['nev']);
    $email = trim($_POST['email']);
    $uzenet = trim($_POST['uzenet']);
    $datum = date('Y-m-d');

    try {
        // Adatok beszúrása az adatbázisba
        $stmt = $pdo->prepare("INSERT INTO urlap (ugyfel_nev, email, uzenetek, statusz, datum) 
                               VALUES (:ugyfel_nev, :email, :uzenet, 0, :datum)");

        $stmt->bindParam(':ugyfel_nev', $ugyfel_nev, PDO::PARAM_STR);
        $stmt->bindParam(':email', $email, PDO::PARAM_STR);
        $stmt->bindParam(':uzenet', $uzenet, PDO::PARAM_STR);
        $stmt->bindParam(':datum', $datum, PDO::PARAM_STR);

        if ($stmt->execute()) {
            echo "<script>alert('Ajánlatkérés sikeresen elküldve!'); window.location.href = 'ajanlatkeres.html';</script>";
        } else {
            echo "<script>alert('Hiba történt az ajánlatkérés mentésekor.'); window.history.back();</script>";
        }
    } catch (PDOException $e) {
        if ($e->getCode() === '23000') {
            echo "<script>alert('Ez az email cím már szerepel az ajánlatkérések között.'); window.history.back();</script>";
        } else {
            echo "<script>alert('Adatbázis hiba: " . $e->getMessage() . "'); window.history.back();</script>";
        }
    }
} else {
    echo "<script>alert('Hibás kérés.'); window.history.back();</script>";
}
?>
