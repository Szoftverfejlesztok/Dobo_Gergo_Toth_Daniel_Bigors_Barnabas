<?php
session_start();
require_once 'config.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST')
{
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);

    try
    {
        $stmt = $pdo->prepare("SELECT * FROM admin WHERE nev = :username");
        $stmt->bindParam(':username', $username, PDO::PARAM_STR);
        $stmt->execute();
        if ($stmt->rowCount() == 1)
        {
            $admin = $stmt->fetch(PDO::FETCH_ASSOC);
            if ($admin['jelszo'] === $password)
            {
                $_SESSION['admin_id'] = $admin['admin_id'];
                $_SESSION['admin_name'] = $admin['nev'];
                header("Location: klima_hozzaadas.php");
                exit();
            }
            else
            {
                echo "<script>alert('Hibás jelszó!'); window.history.back();</script>";
            }
        }
        else
        {
            echo "<script>alert('Nincs ilyen admin felhasználó!'); window.history.back();</script>";
        }
    }
    catch (PDOException $e)
    {
        echo "<script>alert('Adatbázis hiba: " . $e->getMessage() . "'); window.history.back();</script>";
    }
}
?>
