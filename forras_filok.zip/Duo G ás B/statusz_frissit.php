<?php
require_once 'config.php';

if (isset($_POST['update_status'])) {
    $rendeles_id = $_POST['rendeles_id'];

    try {
        // Az adatbázisban a statusz frissítése
        $sql = "UPDATE urlap SET statusz = 1 WHERE id = :id";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':id', $rendeles_id, PDO::PARAM_INT);
        $stmt->execute();

        // Visszairányítás az admin felületre
        header('Location: admin_felulet.php');
        exit;
    } catch (PDOException $e) {
        echo "Hiba történt: " . $e->getMessage();
    }
}
?>
