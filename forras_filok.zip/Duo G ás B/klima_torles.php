<?php
require_once 'config.php';

// Klíma törlés
if (isset($_GET['id'])) {
    $termek_id = $_GET['id'];

    try {
        $stmt = $pdo->prepare("DELETE FROM termekek WHERE termek_id = :id");
        $stmt->bindParam(':id', $termek_id, PDO::PARAM_INT);

        if ($stmt->execute()) {
            echo "<script>alert('Klíma sikeresen törölve!'); window.location.href = 'klima_hozzaadas.php';</script>";
        } else {
            echo "<script>alert('Hiba történt a törlés során.'); window.history.back();</script>";
        }
    } catch (PDOException $e) {
        echo "<script>alert('Hiba: " . $e->getMessage() . "'); window.history.back();</script>";
    }
}
?>

